//create database EmployeeSystem;
//use EmployeeSystem;
//create table  emp(
//		
//		create table emp(
//			    -> id int auto_increment,
//			    -> name varchar(4000),
//			    -> password varchar(4000),
//			    -> email varchar(4000),
//			    -> country varchar(4000),
//			    -> primary key(id));
//		
//desc emp;

