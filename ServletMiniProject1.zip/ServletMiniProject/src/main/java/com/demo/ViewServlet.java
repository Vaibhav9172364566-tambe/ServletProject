package com.demo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/view")
public class ViewServlet extends HttpServlet {
	
	
	 @Override
	protected void doGet(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			
			out.print("<h1> Employee data</h1>");
			
			
			List<Employee>  list = EmpDao.getAllEmployee();
			
			   
			
//			 for(Employee e : list)
//			 {
//				    out.print(e.getId());
//				 
//			 }
			
			
			
			   out.print("<table  border='1' width='100%' cellpadding='25' cellspacing='0'>");
			   
			    out.print("<tr>   <th>ID</th> <th>Name</th>    <th>Password</th>   <th>email</th>   <th>country</th>  <th>Edit</th> <th>Delet</th>   </tr>");
			   

				 for(Employee e : list)
				 {
					      
					 
					 out.print("<tr>");
					 out.print("<td>"+  e.getId()+"</td>");
					 out.print("<td>"+  e.getName()+"</td>");
					 out.print("<td>"+  e.getPassword()+"</td>");
					 out.print("<td>"+  e.getEmail()+"</td>");
					 out.print("<td>"+  e.getCountry()+"</td>");
				   
            	     out.print("<td><a href='editServlet?id="+e.getId()+"'>Edit</td>");
            	     out.print("<td><a href='deletServlet?id="+e.getId()+"'>Delet </td>");
					 
					 out.print("</tr>");
					 
				 }
			   
			   out.print("</table>");
			
			
			
			
			
			
			  
	             
	            
	            
	            
			
			
			
			
			
			
			
			
			
			
	}
	
	

}
