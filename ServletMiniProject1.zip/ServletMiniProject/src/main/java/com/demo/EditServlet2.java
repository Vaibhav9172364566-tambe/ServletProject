package com.demo;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.security.auth.message.callback.PrivateKeyCallback.Request;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/editServlet2")
public class EditServlet2 extends HttpServlet {
	
	
	 @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			
			out.print("<h1> Update Employee </h1>");
			
			  String sid=request.getParameter("id");  
	          int id=Integer.parseInt(sid);  
	          String name=request.getParameter("name");  
	          String password=request.getParameter("password");  
	          String email=request.getParameter("email");  
	          String country=request.getParameter("country");  
			 
	          
	          Employee e=new Employee();  
	          e.setId(id);  
	          e.setName(name);  
	          e.setPassword(password);  
	          e.setEmail(email);  
	          e.setCountry(country);  
			
	                
	            int status = EmpDao.update(e);
	            
	             if(status>0)
	             {
	            	   response.sendRedirect("view");
	             }else
	             {
	            	  out.print("unable to update data");
	             }
	            
	            
			   
			
			
	 }
}
