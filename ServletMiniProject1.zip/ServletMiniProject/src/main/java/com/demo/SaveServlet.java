package com.demo;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/save")
public class SaveServlet extends HttpServlet {



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		  
		String name=request.getParameter("name");
		String password = request.getParameter("password");
		String email= request.getParameter("email");
		String country = request.getParameter("country");
		
		
		   Employee e= new Employee();
		   
		      e.setName(name);
		      e.setPassword(password);
		      e.setEmail(email);
		      e.setCountry(country);
		
//		     out.print(e);
		
		     
		     int status=EmpDao.save(e);
		     
		       if(status>0)
		       {
		    	      out.print("<h>Record save successfully</h1>");
		    	      request.getRequestDispatcher("index.html").include(request, response);
		       }else
		       {
		    	   out.print("<h>ssomething went wrong</h1>");
		       }
		
	}

}
